# Aloha Cats by Angela — Hawaiian Redesign
Beachy teal + coral palette, wave accents, and high-contrast admin.
## Quick start
npm install
npm run dev
## Build for deploy
npm run build   # outputs to dist/
