import React from 'react'
import AdoptionApp from './AdoptionApp.jsx'
export default function App(){ return <AdoptionApp/> }
