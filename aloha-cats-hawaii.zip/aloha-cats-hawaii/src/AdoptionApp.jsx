import React, { useEffect, useMemo, useRef, useState } from "react";

/** ===================================
 * Aloha Cats by Angela – Hawaiian Theme
 * Beachy palette, wave accents, hibiscus emoji,
 * high-contrast admin, localStorage data.
 * =================================== */

const RESCUE_NAME = "Aloha Cats by Angela";
const RESCUE_EMAIL = "alohacatsbyangela@gmail.com";
const STORAGE_KEY = "aloha_cats_animals_v1";

function cryptoRandomId() {
  if ("randomUUID" in crypto) return crypto.randomUUID();
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

const SEED_ANIMALS = [
  { id: cryptoRandomId(), name: "Mango", species: "Cat", breed: "DSH", sex: "Female", ageYears: 2, size:"Small", color:"Orange", photos:["https://images.unsplash.com/photo-1518791841217-8f162f1e1131?q=80&w=1400&auto=format&fit=crop"], houseTrained:true, fixed:true, shotsUpToDate:true, goodWith:["Cats"], description:"Friendly, curious, and loves sunny naps.", intakeDate: new Date(Date.now()-1000*60*60*24*9).toISOString(), location:"Foster — Honolulu, HI", status:"available", tags:["Affectionate","Playful"]},
  { id: cryptoRandomId(), name: "Liko", species: "Cat", breed: "DSH", sex: "Male", ageYears: 3.2, size:"Small", color:"Black", photos:["https://images.unsplash.com/photo-1516280440614-37939bbacd81?q=80&w=1400&auto=format&fit=crop"], houseTrained:true, fixed:true, shotsUpToDate:true, goodWith:["Kids"], description:"Chill lap cat with big purrs.", intakeDate: new Date(Date.now()-1000*60*60*24*18).toISOString(), location:"Shelter — O‘ahu, HI", status:"available", tags:["Calm","Lap Cat"]},
  { id: cryptoRandomId(), name: "Nalu", species: "Dog", breed: "Mix", sex: "Female", ageYears: 4.5, size:"Medium", color:"Tan", photos:["https://images.unsplash.com/photo-1543466835-00a7907e9de1?q=80&w=1400&auto=format&fit=crop"], houseTrained:true, fixed:true, shotsUpToDate:true, goodWith:["Kids","Dogs"], description:"Beach walk enthusiast. Knows sit & stay.", intakeDate: new Date(Date.now()-1000*60*60*24*6).toISOString(), location:"Foster — Kailua, HI", status:"pending", tags:["Gentle","Cuddler"]},
];

function classNames(...xs){ return xs.filter(Boolean).join(" "); }
function readableDate(iso){ const d = new Date(iso); return d.toLocaleDateString(undefined,{year:"numeric",month:"short",day:"numeric"}); }
function useLocalStorage(key, initial){
  const [v,setV] = useState(() => { try{ const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : initial; }catch{return initial;} });
  useEffect(()=>{ try{ localStorage.setItem(key, JSON.stringify(v)); }catch{} }, [key,v]);
  return [v,setV];
}
function useFavorites(){
  const [ids,setIds] = useLocalStorage("aloha_favs_v1", []);
  return { ids, toggle:(id)=>setIds(prev=> prev.includes(id)? prev.filter(x=>x!==id): [...prev,id]) };
}
function mailtoInquiry(a){
  const subject = encodeURIComponent(`Adoption Inquiry: ${a.name} (#${a.id.slice(0,6)})`);
  const body = encodeURIComponent([
    `Aloha ${RESCUE_NAME},`,"",`I'm interested in ${a.name}. Please let me know next steps!`,"","My Details:","Name:","Phone:","City/State:","Home type:","Other pets:","","Mahalo!"
  ].join("\\n"));
  return `mailto:${RESCUE_EMAIL}?subject=${subject}&body=${body}`;
}

// Dark mode (optional)
function useTheme(){
  const [theme,setTheme] = useLocalStorage("theme","light");
  useEffect(()=>{ const root = document.documentElement; theme==="dark" ? root.classList.add("dark") : root.classList.remove("dark"); },[theme]);
  return { theme, setTheme };
}

// Reusable UI
function Button({children,className="",...p}){
  return <button {...p} className={classNames("rounded-xl border px-3 py-2 text-sm hover:bg-white/60 dark:hover:bg-zinc-800", className)}>{children}</button>;
}
function Badge({children,className=""}){
  return <span className={classNames("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold border", className)}>{children}</span>;
}
function Pill({children}){ return <span className="inline-block rounded-full border px-2 py-1 text-xs mr-1 mb-1">{children}</span>; }
function Modal({open,onClose,children}){
  if(!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose}/>
      <div className="relative z-10 max-h-[90vh] w-[min(100%-1rem,960px)] overflow-auto rounded-2xl bg-white dark:bg-zinc-900 p-4 md:p-6 shadow-xl border border-zinc-200 dark:border-zinc-800">
        <button onClick={onClose} className="absolute right-3 top-3 rounded-full border px-2 py-1 text-xs hover:bg-zinc-100 dark:hover:bg-zinc-800" aria-label="Close">✕</button>
        {children}
      </div>
    </div>
  );
}

// High-contrast inputs
function TextInput(props){
  return (
    <input {...props} className={`w-full rounded-xl border px-3 py-2 text-sm outline-none
      bg-white text-black placeholder-zinc-400 border-zinc-300
      focus:ring-2 focus:ring-ocean-500/30 focus:border-ocean-500
      dark:bg-zinc-900 dark:text-white dark:placeholder-zinc-500 dark:border-zinc-700 ${props.className||""}`} />
  );
}
function Select(props){
  return (
    <select {...props} className={`w-full rounded-xl border px-3 py-2 text-sm outline-none
      bg-white text-black border-zinc-300
      focus:ring-2 focus:ring-ocean-500/30 focus:border-ocean-500
      dark:bg-zinc-900 dark:text-white dark:border-zinc-700 ${props.className||""}`} />
  );
}
function TextArea(props){
  return (
    <textarea {...props} className={`w-full rounded-xl border px-3 py-2 text-sm outline-none
      bg-white text-black placeholder-zinc-400 border-zinc-300
      focus:ring-2 focus:ring-ocean-500/30 focus:border-ocean-500
      dark:bg-zinc-900 dark:text-white dark:placeholder-zinc-500 dark:border-zinc-700 ${props.className||""}`} />
  );
}
function Toggle({checked,onChange,label}){
  return <label className="flex items-center gap-2 text-sm select-none"><input type="checkbox" checked={checked} onChange={e=>onChange?.(e.target.checked)}/><span>{label}</span></label>;
}

export default function AdoptionApp(){
  const [animals,setAnimals] = useLocalStorage(STORAGE_KEY, SEED_ANIMALS);
  const [query,setQuery] = useState("");
  const [species,setSpecies] = useState("All");
  const [status,setStatus] = useState("All");
  const [goodWith,setGoodWith] = useState("Any");
  const [sort,setSort] = useState("Newest");
  const [selected,setSelected] = useState(null);
  const [showManage,setShowManage] = useState(false);
  const favs = useFavorites();
  const { theme, setTheme } = useTheme();

  const filtered = useMemo(()=>{
    const q = query.trim().toLowerCase();
    let list = animals.filter(a =>
      (species==="All"||a.species===species) &&
      (status==="All"||a.status===status) &&
      (goodWith==="Any"||a.goodWith?.includes(goodWith)) &&
      (!q || [a.name,a.breed,a.color,a.location,a.description,...(a.tags||[])].filter(Boolean).some(t=>t.toLowerCase().includes(q)))
    );
    list.sort((a,b)=>{
      if(sort==="Age ↑") return a.ageYears-b.ageYears;
      if(sort==="Age ↓") return b.ageYears-a.ageYears;
      if(sort==="Name A→Z") return a.name.localeCompare(b.name);
      if(sort==="Name Z→A") return b.name.localeCompare(a.name);
      return new Date(b.intakeDate)-new Date(a.intakeDate);
    });
    return list;
  },[animals,query,species,status,goodWith,sort]);

  return (
    <div className="min-h-screen text-zinc-800 dark:text-zinc-100 bg-sand dark:bg-zinc-950">
      {/* Top bar */}
      <nav className="sticky top-0 z-40 border-b bg-sand/80 dark:bg-zinc-950/70 backdrop-blur border-zinc-200 dark:border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
          <a href="#" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-ocean-500 text-white grid place-items-center text-xl">🌺</div>
            <div className="brand text-2xl leading-none">Aloha Cats by Angela</div>
          </a>
          <div className="hidden md:flex items-center gap-1 ml-4">
            <a href="#adopt" className="px-3 py-2 rounded-lg hover:bg-white/70 dark:hover:bg-zinc-900">Adopt</a>
            <a href="#how" className="px-3 py-2 rounded-lg hover:bg-white/70 dark:hover:bg-zinc-900">How it works</a>
            <a href="#about" className="px-3 py-2 rounded-lg hover:bg-white/70 dark:hover:bg-zinc-900">About</a>
            <a href="#donate" className="px-3 py-2 rounded-lg hover:bg-white/70 dark:hover:bg-zinc-900">Donate</a>
          </div>
          <div className="flex-1" />
          <Button onClick={()=>setTheme(theme==="dark"?"light":"dark")} title="Toggle theme">{theme==="dark"?"🌙":"☀️"}</Button>
          <Button onClick={()=>setShowManage(true)} className="ml-2">⚙️ Manage</Button>
        </div>
      </nav>

      {/* Hero */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <img src="https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?q=80&w=2000&auto=format&fit=crop" alt="Hawaiian beach" className="w-full h-full object-cover"/>
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/20 to-sand dark:to-zinc-950" />
        </div>
        <div className="max-w-7xl mx-auto px-4 py-20 md:py-28 text-white">
          <h1 className="text-4xl md:text-6xl font-extrabold leading-tight bg-gradient-to-r from-coral-500 to-ocean-500 bg-clip-text text-transparent">Bring a little aloha home.</h1>
          <p className="mt-3 text-lg md:text-xl max-w-2xl text-palm-500">Adopt or support island pets. We’re volunteer-run and community-powered.</p>
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <a href="#adopt" className="rounded-xl border px-4 py-2 text-base bg-white/90 text-black hover:bg-white">Browse pets</a>
            <a href="#donate" className="rounded-xl border px-4 py-2 text-base bg-coral-500 text-white hover:bg-coral-600 border-coral-600">Donate</a>
          </div>
        </div>
        <img src="/wave.svg" alt="" className="w-full block" />
      </header>

      {/* Adopt grid + filters */}
      <main id="adopt" className="max-w-7xl mx-auto px-4 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <aside className="lg:col-span-1">
            <div className="lg:sticky lg:top-20">
              <div className="rounded-2xl border p-4 bg-white/90 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold">Filters</h2>
                  <button onClick={()=>{setQuery('');setSpecies('All');setStatus('All');setGoodWith('Any');setSort('Newest');}} className="text-sm underline">Reset</button>
                </div>
                <div className="mt-3 space-y-3">
                  <TextInput placeholder="Search by name, breed, color…" value={query} onChange={e=>setQuery(e.target.value)} />
                  <div>
                    <label className="text-sm font-medium text-black dark:text-white">Species</label>
                    <Select value={species} onChange={e=>setSpecies(e.target.value)}>
                      {["All","Cat","Dog","Rabbit","Bird","Other"].map(s=><option key={s} value={s}>{s}</option>)}
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-black dark:text-white">Status</label>
                    <Select value={status} onChange={e=>setStatus(e.target.value)}>
                      {["All","available","pending","adopted"].map(s=><option key={s} value={s}>{s[0].toUpperCase()+s.slice(1)}</option>)}
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-black dark:text-white">Good with</label>
                    <Select value={goodWith} onChange={e=>setGoodWith(e.target.value)}>
                      {["Any","Kids","Dogs","Cats"].map(s=><option key={s} value={s}>{s}</option>)}
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-black dark:text-white">Sort</label>
                    <Select value={sort} onChange={e=>setSort(e.target.value)}>
                      {["Newest","Oldest","Age ↑","Age ↓","Name A→Z","Name Z→A"].map(s=><option key={s} value={s}>{s}</option>)}
                    </Select>
                  </div>
                </div>
              </div>
            </div>
          </aside>

          <section className="lg:col-span-3">
            {filtered.length===0 ? (
              <div className="rounded-2xl border p-6 text-center text-zinc-500">No animals match your filters yet.</div>
            ) : (
              <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-5">
                {filtered.map(a => (
                  <div key={a.id} className="group rounded-2xl overflow-hidden border bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 shadow-sm hover:shadow-md transition">
                    <div className="relative aspect-[4/3] overflow-hidden">
                      <img src={a.photos?.[0]} alt={a.name} className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform"/>
                      <div className="absolute left-3 top-3 flex gap-2">
                        <Badge className={classNames("bg-white/90 dark:bg-zinc-900/90", a.status==="pending"&&"ring-2 ring-coral-500/60", a.status==="adopted"&&"ring-2 ring-palm-500/60")}>
                          {a.status[0].toUpperCase()+a.status.slice(1)}
                        </Badge>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <h3 className="text-lg font-semibold">{a.name}</h3>
                          <div className="text-sm text-zinc-600 dark:text-zinc-400">{a.species} • {a.breed}</div>
                        </div>
                        <button onClick={()=>favs.toggle(a.id)} className="rounded-xl border px-2 py-1 text-sm">{favs.ids.includes(a.id)?"❤️":"🤍"}</button>
                      </div>
                      <div className="mt-2 flex flex-wrap">{a.tags?.slice(0,3).map(t => <Pill key={t}>{t}</Pill>)}</div>
                      <div className="mt-4 flex gap-2">
                        <Button onClick={()=>setSelected(a)} className="flex-1">Details</Button>
                        <a href={mailtoInquiry(a)} className="flex-1 rounded-xl border px-3 py-2 text-sm text-center hover:bg-white/70 dark:hover:bg-zinc-800">Inquire</a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        {/* How it works */}
        <section id="how" className="mt-16 rounded-2xl border p-6 bg-white/90 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
          <h2 className="text-2xl font-extrabold brand">How adoption works</h2>
          <ol className="mt-4 grid md:grid-cols-3 gap-4 text-sm">
            <li className="rounded-xl border p-4"><div className="font-semibold mb-1">1) Meet & Match</div><p>Browse, favorite pets, and submit an inquiry. We’ll suggest a great match for your home.</p></li>
            <li className="rounded-xl border p-4"><div className="font-semibold mb-1">2) Apply</div><p>Complete a short application and chat with our volunteers to confirm the basics.</p></li>
            <li className="rounded-xl border p-4"><div className="font-semibold mb-1">3) Welcome home</div><p>Schedule a meet-and-greet, finalize paperwork, and bring your new friend home.</p></li>
          </ol>
        </section>

        {/* About & Donate */}
        <section id="about" className="mt-16 grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 rounded-2xl border p-6 bg-white/90 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
            <h2 className="text-2xl font-extrabold brand">About {RESCUE_NAME}</h2>
            <p className="mt-2 text-sm leading-6 text-zinc-700 dark:text-zinc-300">We’re a Hawaiian, volunteer-run rescue focused on saving cats and dogs, placing them in loving homes, and supporting fosters with supplies and vet care. Your support lets us say “yes” more often. Mahalo!</p>
          </div>
          <div id="donate" className="rounded-2xl border p-6 bg-gradient-to-br from-ocean-500 to-palm-500 text-white">
            <h3 className="text-xl font-semibold brand">Support our rescue</h3>
            <p className="mt-1 text-white/90 text-sm">Donations cover food, spay/neuter, vaccines, and emergency care.</p>
            <a href="https://example.org/donate" target="_blank" className="mt-4 inline-block rounded-xl border border-white/40 px-4 py-2">Donate</a>
          </div>
        </section>
      </main>

      <footer className="max-w-7xl mx-auto px-4 py-12 text-sm text-zinc-600 dark:text-zinc-400">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div>© {new Date().getFullYear()} {RESCUE_NAME}. All rights reserved.</div>
          <div className="flex items-center gap-3">
            <a className="underline" href={`mailto:${RESCUE_EMAIL}`}>Contact</a>
            <button className="underline" onClick={()=>{ localStorage.removeItem(STORAGE_KEY); location.reload(); }}>Reset Demo Data</button>
          </div>
        </div>
      </footer>

      <AnimalModal animal={selected} onClose={()=>setSelected(null)} />
      <ManageDrawer open={showManage} onClose={()=>setShowManage(false)} animals={animals} setAnimals={setAnimals} />
    </div>
  );
}

// Animal modal
function AnimalModal({ animal, onClose }){
  const [index,setIndex] = useState(0);
  useEffect(()=>setIndex(0),[animal?.id]);
  if(!animal) return null;
  const next = ()=>setIndex(i=>(i+1) % (animal.photos?.length||1));
  const prev = ()=>setIndex(i=>(i-1 + (animal.photos?.length||1)) % (animal.photos?.length||1));
  return (
    <Modal open={!!animal} onClose={onClose}>
      <div className="grid md:grid-cols-2 gap-6">
        <div className="relative rounded-2xl overflow-hidden border">
          <img src={animal.photos?.[index]} alt={animal.name} className="w-full h-[320px] object-cover"/>
          {animal.photos?.length>1 && (
            <div className="absolute inset-0 flex items-center justify-between px-2">
              <button onClick={prev} className="rounded-full bg-white/90 dark:bg-zinc-900/90 border px-2 py-1">◀</button>
              <button onClick={next} className="rounded-full bg-white/90 dark:bg-zinc-900/90 border px-2 py-1">▶</button>
            </div>
          )}
        </div>
        <div>
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="text-2xl font-bold">{animal.name}</h3>
              <div className="text-sm text-zinc-500">#{animal.id.slice(0,6)} • Intake {readableDate(animal.intakeDate)}</div>
            </div>
            <a href={mailtoInquiry(animal)} className="rounded-xl border px-3 py-2 text-sm">📧 Inquire</a>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Badge>{animal.species}</Badge>
            <Badge>{animal.sex}</Badge>
            <Badge>{animal.size}</Badge>
            <Badge>{animal.color}</Badge>
            <Badge className="uppercase">{animal.status}</Badge>
          </div>
          <p className="mt-4 text-sm leading-6 whitespace-pre-line">{animal.description}</p>
          <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-xl border p-3">
              <div className="font-medium mb-1">House & Health</div>
              <ul className="space-y-1 text-zinc-600 dark:text-zinc-300">
                <li>House-trained: {animal.houseTrained? "Yes":"No/Unknown"}</li>
                <li>Fixed/Spayed: {animal.fixed? "Yes":"No/Unknown"}</li>
                <li>Shots up-to-date: {animal.shotsUpToDate? "Yes":"No/Unknown"}</li>
              </ul>
            </div>
            <div className="rounded-xl border p-3">
              <div className="font-medium text-sm mb-2">Good With</div>
              <div className="flex flex-wrap mt-1">{animal.goodWith?.length? animal.goodWith.map(g=><Pill key={g}>{g}</Pill>): <span className="text-zinc-500">Unknown</span>}</div>
            </div>
          </div>
          <div className="mt-4 text-sm text-zinc-600 dark:text-zinc-300">Location: {animal.location}</div>
        </div>
      </div>
    </Modal>
  );
}

// Admin drawer
function ManageDrawer({ open, onClose, animals, setAnimals }){
  const [tab,setTab] = useState("add");
  const [draft,setDraft] = useState({ species:"Cat", sex:"Female", size:"Small", goodWith:[] });
  const [uploading,setUploading] = useState(false);
  const fileRef = useRef(null);
  const [notice,setNotice] = useState("");

  useEffect(()=>{ if(!open) setTab("add") },[open]);

  function handleAdd(){
    const id = cryptoRandomId();
    const now = new Date().toISOString();
    const toAdd = {
      id,
      name: draft.name?.trim() || "Unnamed",
      species: draft.species || "Cat",
      breed: draft.breed || "",
      sex: draft.sex || "Unknown",
      ageYears: Number(draft.ageYears || 0),
      size: draft.size || "Unknown",
      color: draft.color || "",
      photos: draft.photos?.length? draft.photos: [],
      houseTrained: !!draft.houseTrained,
      fixed: !!draft.fixed,
      shotsUpToDate: !!draft.shotsUpToDate,
      goodWith: draft.goodWith || [],
      description: draft.description || "",
      intakeDate: draft.intakeDate || now,
      location: draft.location || "",
      status: draft.status || "available",
      tags: draft.tags || [],
    };
    setAnimals(prev=>[toAdd,...prev]);
    setDraft({ species:"Cat", sex:"Female", size:"Small", goodWith:[] });
    setNotice("Animal added!");
    setTimeout(()=>setNotice(""),3000);
  }
  function handleDelete(id){
    if(!confirm("Delete this animal?")) return;
    setAnimals(prev=>prev.filter(a=>a.id!==id));
  }
  function handleExport(){
    const data = JSON.stringify(animals,null,2);
    const blob = new Blob([data],{type:"application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "animals.json"; a.click(); URL.revokeObjectURL(url);
  }
  function handleImport(text){
    try{
      const arr = JSON.parse(text);
      if(!Array.isArray(arr)) throw new Error("JSON must be an array of animals");
      const normalized = arr.map(a=>({ ...a, id: a.id || cryptoRandomId(), intakeDate: a.intakeDate || new Date().toISOString() }));
      setAnimals(normalized);
      setNotice(`Imported ${normalized.length} animals.`);
      setTimeout(()=>setNotice(""),3000);
    }catch(e){
      alert("Invalid JSON: " + e.message);
    }
  }
  async function onPhotosSelected(files){
    setUploading(true);
    const readers = Array.from(files||[]).map(file=>new Promise(res=>{ const fr = new FileReader(); fr.onload=()=>res(fr.result); fr.readAsDataURL(file); }));
    const results = await Promise.all(readers);
    setDraft(d=>({...d, photos:[...(d.photos||[]), ...results]}));
    setUploading(false);
  }

  return (
    <div className={classNames("fixed inset-0 z-50", open? "":"pointer-events-none")}>
      <div className={classNames("absolute inset-0 bg-black/40 transition-opacity", open? "opacity-100":"opacity-0")} onClick={onClose}/>
      <div className={classNames("absolute right-0 top-0 h-full w-[min(100%,760px)] bg-white dark:bg-zinc-950 border-l border-zinc-200 dark:border-zinc-800 shadow-2xl transition-transform", open? "translate-x-0":"translate-x-full")}>
        <div className="p-5 h-full flex flex-col">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold brand">Manage Animals</h3>
            <Button onClick={onClose}>Close</Button>
          </div>

          {notice && <div className="mt-3 mb-2 rounded-lg border px-4 py-2 font-semibold shadow bg-white text-black dark:bg-black dark:text-white">{notice}</div>}

          <div className="mt-3 flex gap-2">
            <Button onClick={()=>setTab("add")} className={tab==="add"?"bg-white/70 dark:bg-zinc-900":""}>Add / Edit</Button>
            <Button onClick={()=>setTab("import")} className={tab==="import"?"bg-white/70 dark:bg-zinc-900":""}>Bulk Import</Button>
            <Button onClick={handleExport}>Export JSON</Button>
          </div>

          {tab==="add" && (
            <div className="mt-4 overflow-auto pr-1">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="text-sm font-medium text-black dark:text-white">Name</label>
                  <TextInput value={draft.name||""} onChange={e=>setDraft({...draft, name:e.target.value})}/>
                </div>
                <div>
                  <label className="text-sm font-medium text-black dark:text-white">Species</label>
                  <Select value={draft.species||"Cat"} onChange={e=>setDraft({...draft, species:e.target.value})}>
                    {["Dog","Cat","Rabbit","Bird","Other"].map(s=><option key={s} value={s}>{s}</option>)}
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-black dark:text-white">Sex</label>
                  <Select value={draft.sex||"Unknown"} onChange={e=>setDraft({...draft, sex:e.target.value})}>
                    {["Male","Female","Unknown"].map(s=><option key={s} value={s}>{s}</option>)}
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-black dark:text-white">Age (years)</label>
                  <TextInput type="number" min={0} step={0.1} value={draft.ageYears??""} onChange={e=>setDraft({...draft, ageYears:e.target.value})}/>
                </div>
                <div>
                  <label className="text-sm font-medium text-black dark:text-white">Size</label>
                  <Select value={draft.size||"Unknown"} onChange={e=>setDraft({...draft, size:e.target.value})}>
                    {["Small","Medium","Large","XL","Unknown"].map(s=><option key={s} value={s}>{s}</option>)}
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-black dark:text-white">Breed</label>
                  <TextInput value={draft.breed||""} onChange={e=>setDraft({...draft, breed:e.target.value})}/>
                </div>
                <div>
                  <label className="text-sm font-medium text-black dark:text-white">Color</label>
                  <TextInput value={draft.color||""} onChange={e=>setDraft({...draft, color:e.target.value})}/>
                </div>
                <div className="col-span-2">
                  <label className="text-sm font-medium text-black dark:text-white">Location</label>
                  <TextInput value={draft.location||""} onChange={e=>setDraft({...draft, location:e.target.value})}/>
                </div>
                <div className="col-span-2">
                  <label className="text-sm font-medium text-black dark:text-white">Description</label>
                  <TextArea rows={4} value={draft.description||""} onChange={e=>setDraft({...draft, description:e.target.value})}/>
                </div>

                <div className="col-span-2 grid grid-cols-2 gap-3">
                  <div className="rounded-xl border p-3 space-y-2">
                    <div className="font-medium text-sm">House & Health</div>
                    <Toggle label="House-trained" checked={!!draft.houseTrained} onChange={v=>setDraft({...draft, houseTrained:v})}/>
                    <Toggle label="Fixed/Spayed" checked={!!draft.fixed} onChange={v=>setDraft({...draft, fixed:v})}/>
                    <Toggle label="Shots up-to-date" checked={!!draft.shotsUpToDate} onChange={v=>setDraft({...draft, shotsUpToDate:v})}/>
                  </div>
                  <div className="rounded-xl border p-3">
                    <div className="font-medium text-sm mb-2">Good With</div>
                    {["Kids","Dogs","Cats"].map(g=>(
                      <label key={g} className="block text-sm">
                        <input type="checkbox" className="mr-2" checked={draft.goodWith?.includes(g)||false}
                          onChange={e=>{ setDraft(d=>{ const set = new Set(d.goodWith||[]); if(e.target.checked) set.add(g); else set.delete(g); return {...d, goodWith:Array.from(set)};}); }}/>
                        {g}
                      </label>
                    ))}
                  </div>
                </div>

                <div className="col-span-2">
                  <label className="text-sm font-medium text-black dark:text-white">Tags (comma separated)</label>
                  <TextInput placeholder="Playful, House-Trained, Good with Kids" value={(draft.tags||[]).join(", ")}
                    onChange={e=>setDraft({...draft, tags:e.target.value.split(",").map(s=>s.trim()).filter(Boolean)})}/>
                </div>

                <div className="col-span-2 rounded-xl border p-3">
                  <div className="flex items-center justify-between">
                    <div className="font-medium text-sm">Photos</div>
                    <div className="flex gap-2">
                      <Button onClick={()=>fileRef.current?.click()} disabled={uploading}>{uploading? "Uploading…":"Upload files"}</Button>
                      <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={e=>onPhotosSelected(e.target.files)}/>
                    </div>
                  </div>
                  <div className="mt-2">
                    <label className="text-sm">Or paste image URLs (comma separated)</label>
                    <TextInput placeholder="https://example.com/img1.jpg, https://example.com/img2.jpg"
                      value={(draft.photos||[]).filter(p=>typeof p==="string" && p.startsWith("http")).join(", ")}
                      onChange={e=>{ const urls = e.target.value.split(",").map(s=>s.trim()).filter(Boolean);
                        setDraft(d=>({...d, photos:[...urls, ...((d.photos||[]).filter(p=>typeof p!=="string" || !p.startsWith("http")))]})); }}/>
                  </div>
                  {draft.photos?.length ? (
                    <div className="mt-3 grid grid-cols-4 gap-2">
                      {draft.photos.map((p,i)=>(
                        <div key={i} className="relative">
                          <img src={p} alt="preview" className="w-full h-20 object-cover rounded-lg border"/>
                          <button title="Remove" className="absolute -right-2 -top-2 bg-white border rounded-full w-6 h-6"
                            onClick={()=>setDraft(d=>({...d, photos:(d.photos||[]).filter((_,idx)=>idx!==i)}))}>✕</button>
                        </div>
                      ))}
                    </div>
                  ) : <div className="text-sm text-zinc-500 mt-2">No photos yet.</div>}
                </div>

                <div className="col-span-2 flex items-center justify-between mt-2">
                  <div className="flex items-center gap-2">
                    <label className="text-sm font-medium text-black dark:text-white">Status</label>
                    <Select value={draft.status||"available"} onChange={e=>setDraft({...draft, status:e.target.value})}>
                      {["available","pending","adopted"].map(s=><option key={s} value={s}>{s}</option>)}
                    </Select>
                  </div>
                  <Button onClick={handleAdd}>Add Animal</Button>
                </div>
              </div>

              <div className="mt-8">
                <div className="text-sm font-medium mb-2">All Animals ({animals.length})</div>
                <div className="max-h-64 overflow-auto border rounded-xl">
                  <table className="w-full text-sm">
                    <thead className="sticky top-0 bg-white dark:bg-zinc-900">
                      <tr>
                        <th className="text-left p-2">Name</th>
                        <th className="text-left p-2">Species</th>
                        <th className="text-left p-2">Status</th>
                        <th className="text-left p-2">Intake</th>
                        <th className="p-2">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {animals.map(a=>(
                        <tr key={a.id} className="border-t">
                          <td className="p-2">{a.name}</td>
                          <td className="p-2">{a.species}</td>
                          <td className="p-2">
                            <select value={a.status} onChange={e=>setAnimals(prev=>prev.map(x=>x.id===a.id? {...x, status:e.target.value}: x))} className="rounded-lg border px-2 py-1">
                              <option value="available">available</option>
                              <option value="pending">pending</option>
                              <option value="adopted">adopted</option>
                            </select>
                          </td>
                          <td className="p-2">{readableDate(a.intakeDate)}</td>
                          <td className="p-2 text-center">
                            <Button onClick={()=>setDraft(a)} className="mr-2">Edit</Button>
                            <Button onClick={()=>handleDelete(a.id)}>Delete</Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {tab==="import" && (
            <div className="mt-4 space-y-3">
              <p className="text-sm text-zinc-600 dark:text-zinc-300">Paste a JSON array of animals. Missing <code>id</code> or <code>intakeDate</code> will be auto-filled.</p>
              <TextArea id="importArea" rows={12} placeholder={exampleJson()} />
              <div className="flex items-center justify-end gap-2">
                <Button onClick={()=>{ const el = document.getElementById("importArea"); if(!el) return; handleImport(el.value); }}>Import JSON</Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function exampleJson(){
  const sample = [{
    name:"Hoku", species:"Cat", breed:"DSH", sex:"Male", ageYears:1.5, size:"Small", color:"Gray", photos:["https://images.unsplash.com/photo-1516280440614-37939bbacd81?q=80&w=1400&auto=format&fit=crop"], houseTrained:true, fixed:true, shotsUpToDate:true, goodWith:["Cats","Kids"], description:"Sweet and playful island kitty.", intakeDate:"2025-08-01T00:00:00.000Z", location:"Honolulu, HI", status:"available", tags:["Sweet","Playful"]
  }];
  return JSON.stringify(sample,null,2);
}
