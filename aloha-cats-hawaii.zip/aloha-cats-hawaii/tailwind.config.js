/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        sand: { DEFAULT: '#FFF5E6' },
        ocean: { 500: '#14b8a6', 600:'#0ea5a3' },
        coral: { 500: '#fb7185', 600:'#f43f5e' },
        palm: { 500:'#10b981', 600:'#059669' }
      }
    }
  },
  plugins: [],
}
